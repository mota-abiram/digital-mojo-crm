import {
    collection,
    getDocs,
    addDoc,
    updateDoc,
    deleteDoc,
    doc,
    query,
    orderBy
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Contact, Opportunity, Appointment } from '../types';

export const api = {
    contacts: {
        getAll: async () => {
            try {
                const q = query(collection(db, 'contacts'), orderBy('createdAt', 'desc'));
                const snapshot = await getDocs(q);
                return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Contact));
            } catch (error) {
                console.error("Error fetching contacts:", error);
                return [];
            }
        },
        create: async (contact: Omit<Contact, 'id'>) => {
            const docRef = await addDoc(collection(db, 'contacts'), {
                ...contact,
                createdAt: new Date().toISOString()
            });
            return { id: docRef.id, ...contact };
        },
        update: async (id: string, contact: Partial<Contact>) => {
            await updateDoc(doc(db, 'contacts', id), contact);
        },
        delete: async (id: string) => {
            await deleteDoc(doc(db, 'contacts', id));
        }
    },
    opportunities: {
        getAll: async () => {
            try {
                const snapshot = await getDocs(collection(db, 'opportunities'));
                return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Opportunity));
            } catch (error) {
                console.error("Error fetching opportunities:", error);
                return [];
            }
        },
        create: async (opp: Omit<Opportunity, 'id'>) => {
            const docRef = await addDoc(collection(db, 'opportunities'), {
                ...opp,
                createdAt: new Date().toISOString()
            });
            return { id: docRef.id, ...opp };
        },
        update: async (id: string, opp: Partial<Opportunity>) => {
            await updateDoc(doc(db, 'opportunities', id), opp);
        },
        delete: async (id: string) => {
            await deleteDoc(doc(db, 'opportunities', id));
        }
    },
    appointments: {
        getAll: async () => {
            try {
                const snapshot = await getDocs(collection(db, 'appointments'));
                return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Appointment));
            } catch (error) {
                console.error("Error fetching appointments:", error);
                return [];
            }
        },
        create: async (apt: Omit<Appointment, 'id'>) => {
            const docRef = await addDoc(collection(db, 'appointments'), {
                ...apt,
                createdAt: new Date().toISOString()
            });
            return { id: docRef.id, ...apt };
        },
        update: async (id: string, apt: Partial<Appointment>) => {
            await updateDoc(doc(db, 'appointments', id), apt);
        },
        delete: async (id: string) => {
            await deleteDoc(doc(db, 'appointments', id));
        }
    },
    conversations: {
        getAll: async () => {
            // For now, we might want to fetch conversations. 
            // In a real app, this would be complex (users, last message).
            // We will mock this or fetch from a 'conversations' collection.
            try {
                const snapshot = await getDocs(collection(db, 'conversations'));
                return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
            } catch (error) {
                return [];
            }
        },
        sendMessage: async (conversationId: string, message: any) => {
            // In a real app, add to subcollection 'messages'
            const messagesRef = collection(db, `conversations/${conversationId}/messages`);
            await addDoc(messagesRef, {
                ...message,
                timestamp: new Date().toISOString()
            });
            // Update last message in conversation
            await updateDoc(doc(db, 'conversations', conversationId), {
                lastMessage: message.text,
                time: new Date().toISOString(),
                unread: false
            });
        }
    },
    notifications: {
        getAll: async () => {
            // Mock notifications
            return [
                { id: '1', text: 'New lead assigned', read: false },
                { id: '2', text: 'Meeting in 15 mins', read: false }
            ];
        }
    }
};
