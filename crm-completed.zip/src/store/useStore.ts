import { create } from 'zustand';
import { Contact, Opportunity, Appointment, Conversation } from '../types';
import { api } from '../services/api';

interface AppState {
    contacts: Contact[];
    opportunities: Opportunity[];
    appointments: Appointment[];
    isLoading: boolean;

    fetchContacts: () => Promise<void>;
    addContact: (contact: Omit<Contact, 'id'>) => Promise<void>;
    updateContact: (id: string, contact: Partial<Contact>) => Promise<void>;
    deleteContact: (id: string) => Promise<void>;

    fetchOpportunities: () => Promise<void>;
    addOpportunity: (opp: Omit<Opportunity, 'id'>) => Promise<void>;
    updateOpportunity: (id: string, opp: Partial<Opportunity>) => Promise<void>;

    fetchAppointments: () => Promise<void>;
    addAppointment: (apt: Omit<Appointment, 'id'>) => Promise<void>;

    conversations: Conversation[];
    activeConversationId: string | null;
    setActiveConversation: (id: string) => void;
    fetchConversations: () => Promise<void>;
    sendMessage: (text: string) => Promise<void>;

    notifications: any[];
    fetchNotifications: () => Promise<void>;
}

export const useStore = create<AppState>((set, get) => ({
    contacts: [],
    opportunities: [],
    appointments: [],
    conversations: [],
    activeConversationId: null,
    isLoading: false,

    fetchContacts: async () => {
        set({ isLoading: true });
        const contacts = await api.contacts.getAll();
        set({ contacts, isLoading: false });
    },
    addContact: async (contact) => {
        const newContact = await api.contacts.create(contact);
        set((state) => ({ contacts: [newContact, ...state.contacts] }));
    },
    updateContact: async (id, contact) => {
        await api.contacts.update(id, contact);
        set((state) => ({
            contacts: state.contacts.map((c) => (c.id === id ? { ...c, ...contact } : c)),
        }));
    },
    deleteContact: async (id) => {
        await api.contacts.delete(id);
        set((state) => ({
            contacts: state.contacts.filter((c) => c.id !== id),
        }));
    },

    fetchOpportunities: async () => {
        const opportunities = await api.opportunities.getAll();
        set({ opportunities });
    },
    addOpportunity: async (opp) => {
        const newOpp = await api.opportunities.create(opp);
        set((state) => ({ opportunities: [...state.opportunities, newOpp] }));
    },
    updateOpportunity: async (id, opp) => {
        await api.opportunities.update(id, opp);
        set((state) => ({
            opportunities: state.opportunities.map((o) => (o.id === id ? { ...o, ...opp } : o)),
        }));
    },

    fetchAppointments: async () => {
        const appointments = await api.appointments.getAll();
        set({ appointments });
    },
    addAppointment: async (apt) => {
        const newApt = await api.appointments.create(apt);
        set((state) => ({ appointments: [...state.appointments, newApt] }));
    },

    // Conversations
    setActiveConversation: (id) => set({ activeConversationId: id }),
    fetchConversations: async () => {
        const conversations = await api.conversations.getAll();
        set({ conversations });
    },
    sendMessage: async (text) => {
        const { activeConversationId, conversations } = get();
        if (!activeConversationId) return;

        const message = {
            message: text,
            sender: 'me',
            recipient: 'them', // In real app, get from conversation
            timestamp: new Date().toISOString(),
            id: Date.now().toString()
        };

        await api.conversations.sendMessage(activeConversationId, message);

        // Optimistic update
        set({
            conversations: conversations.map(c => {
                if (c.id === activeConversationId) {
                    return {
                        ...c,
                        lastMessage: text,
                        time: 'Just now',
                        messages: [...(c.messages || []), message]
                    };
                }
                return c;
            })
        });
    },

    notifications: [],
    fetchNotifications: async () => {
        const notifications = await api.notifications.getAll();
        set({ notifications });
    }
}));
