import React, { useEffect } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Target, Users, CheckCircle } from 'lucide-react';
import { useStore } from '../store/useStore';

const Dashboard: React.FC = () => {
  const { opportunities, fetchOpportunities, contacts, fetchContacts } = useStore();

  useEffect(() => {
    fetchOpportunities();
    fetchContacts();
  }, [fetchOpportunities, fetchContacts]);

  // Calculate Stats
  const totalPipelineValue = opportunities.reduce((sum, opp) => sum + Number(opp.value), 0);
  const wonOpportunities = opportunities.filter(opp => opp.stage === 'Closed' || opp.status === 'Won').length;
  const totalOpportunities = opportunities.length;
  const conversionRate = totalOpportunities > 0 ? ((wonOpportunities / totalOpportunities) * 100).toFixed(1) : '0';

  // Funnel Data
  const stages = ['New', 'Contacted', 'Qualified', 'Proposal', 'Closed'];
  const funnelData = stages.map(stage => ({
    name: stage,
    value: opportunities.filter(o => o.stage === stage).length,
    fill: stage === 'New' ? '#05acd6' : stage === 'Contacted' ? '#eb7311' : stage === 'Qualified' ? '#754c9b' : stage === 'Proposal' ? '#f0bc00' : '#1ea34f'
  }));

  // Mock Pipeline Trend (since we don't have historical data stored easily)
  const pipelineData = [
    { name: 'Jan', value: 4000 },
    { name: 'Feb', value: 3000 },
    { name: 'Mar', value: 5000 },
    { name: 'Apr', value: 2780 },
    { name: 'May', value: 1890 },
    { name: 'Jun', value: 2390 },
    { name: 'Jul', value: 3490 },
  ];

  // Task Data (Mock for now as we don't have tasks module)
  const taskData = [
    { name: 'Completed', value: 400 },
    { name: 'Pending', value: 300 },
    { name: 'Overdue', value: 300 },
  ];
  const taskColors = ['#1ea34f', '#05acd6', '#eb7311'];

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <div className="flex gap-2">
          <select className="bg-white border border-gray-300 text-gray-700 text-sm rounded-lg focus:ring-primary focus:border-primary block p-2.5">
            <option>Last 30 Days</option>
            <option>Last 7 Days</option>
            <option>Today</option>
          </select>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Opportunities', value: totalOpportunities.toString(), change: '+5%', isPositive: true, icon: Target },
          { label: 'Pipeline Value', value: `$${totalPipelineValue.toLocaleString()}`, change: '+2.1%', isPositive: true, icon: DollarSign },
          { label: 'Conversion Rate', value: `${conversionRate}%`, change: '-0.5%', isPositive: false, icon: TrendingUp },
          { label: 'Closed Won', value: wonOpportunities.toString(), change: '+12%', isPositive: true, icon: CheckCircle },
        ].map((stat, idx) => (
          <div key={idx} className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-500">{stat.label}</p>
                <h3 className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</h3>
              </div>
              <div className="p-2 bg-gray-50 rounded-lg text-gray-400">
                <stat.icon size={24} />
              </div>
            </div>
            <div className={`mt-4 flex items-center text-sm font-medium ${stat.isPositive ? 'text-green-600' : 'text-red-600'}`}>
              {stat.isPositive ? <TrendingUp size={16} className="mr-1" /> : <TrendingDown size={16} className="mr-1" />}
              {stat.change}
              <span className="text-gray-400 font-normal ml-2">vs last month</span>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Charts Area */}
        <div className="lg:col-span-2 space-y-8">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            {/* Funnel */}
            <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Lead Conversion Funnel</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={funnelData} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} />
                    <Tooltip cursor={{ fill: 'transparent' }} />
                    <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                      {funnelData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Pipeline Trend */}
            <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Pipeline Value Trend</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={pipelineData}>
                    <defs>
                      <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#1ea34f" stopOpacity={0.1} />
                        <stop offset="95%" stopColor="#1ea34f" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} />
                    <Tooltip />
                    <Area type="monotone" dataKey="value" stroke="#1ea34f" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Wide Chart / Task Breakdown */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex flex-col md:flex-row items-center justify-around">
            <div className="w-full md:w-1/2">
              <h3 className="text-lg font-bold text-gray-900 mb-2">Task Distribution</h3>
              <p className="text-sm text-gray-500 mb-6">Overview of team activity status.</p>
              <div className="space-y-3">
                {taskData.map((task, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: taskColors[i] }}></div>
                      <span className="text-sm font-medium text-gray-700">{task.name}</span>
                    </div>
                    <span className="text-sm font-bold text-gray-900">{task.value}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="w-full md:w-1/2 h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={taskData}
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {taskData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={taskColors[index % taskColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Activity Feed */}
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm h-fit">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Activity Feed</h3>
          <div className="space-y-6">
            {[
              { user: 'John Doe', action: 'updated a contact', time: '2 hours ago', img: 'https://picsum.photos/40/40' },
              { user: 'Jane Smith', action: 'sent an email to Client Corp', time: '5 hours ago', img: 'https://picsum.photos/41/41' },
              { user: 'Alex Johnson', action: 'logged a call', time: 'Yesterday', img: 'https://picsum.photos/42/42' },
              { user: 'Emily White', action: 'closed an opportunity', time: '2 days ago', img: 'https://picsum.photos/43/43' },
              { user: 'Michael Brown', action: 'created a task', time: '3 days ago', img: 'https://picsum.photos/44/44' },
            ].map((activity, idx) => (
              <div key={idx} className="flex gap-4 items-start">
                <img src={activity.img} alt={activity.user} className="w-10 h-10 rounded-full object-cover" />
                <div>
                  <p className="text-sm text-gray-900">
                    <span className="font-semibold">{activity.user}</span> {activity.action}.
                  </p>
                  <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-2 text-sm font-medium text-primary hover:bg-primary/5 rounded-lg transition-colors">
            View All Activity
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
