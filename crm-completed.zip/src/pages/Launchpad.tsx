import React from 'react';
import { Smartphone, Share2, Users, Calendar, CreditCard, Box, Check, ChevronRight } from 'lucide-react';

const Launchpad: React.FC = () => {
  return (
    <div className="p-8">
      <div className="grid grid-cols-12 gap-8 max-w-7xl mx-auto">
        {/* Left Column: Progress */}
        <div className="col-span-12 lg:col-span-4">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-6">
            <h2 className="text-xl font-bold text-gray-900">Setup Guide</h2>
            <div className="mt-6 flex flex-col gap-3">
              <div className="flex justify-between items-center">
                <p className="text-sm font-medium text-gray-600">1 of 6 steps completed</p>
                <p className="text-sm font-bold text-success">16%</p>
              </div>
              <div className="h-2.5 rounded-full bg-gray-100 w-full overflow-hidden">
                <div className="h-full rounded-full bg-success transition-all duration-500" style={{ width: '16%' }}></div>
              </div>
            </div>

            <div className="mt-8 space-y-4">
              {[
                { label: 'Download mobile app', checked: true },
                { label: 'Connect Social Media accounts', checked: false },
                { label: 'Add your team members', checked: false },
                { label: 'Integrate Google Calendar', checked: false },
                { label: 'Connect Stripe Account', checked: false },
                { label: 'Explore App Marketplace', checked: false },
              ].map((item, idx) => (
                <label key={idx} className="flex gap-3 items-center cursor-pointer group">
                  <div className={`h-5 w-5 rounded border flex items-center justify-center transition-colors ${item.checked ? 'bg-success border-success' : 'border-gray-300 group-hover:border-success'}`}>
                    {item.checked && <Check size={14} className="text-white" />}
                  </div>
                  <span className={`text-sm font-medium ${item.checked ? 'text-gray-900' : 'text-gray-600'}`}>
                    {item.label}
                  </span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Actions */}
        <div className="col-span-12 lg:col-span-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">
            Let's get you set up!
          </h1>
          <div className="grid grid-cols-1 gap-5">
            {[
              { icon: Smartphone, title: 'Download Mobile App', sub: 'Access your CRM on the go', color: 'text-success', bg: 'bg-success/10' },
              { icon: Share2, title: 'Connect Social Accounts', sub: 'Integrate Facebook, Instagram & more', color: 'text-primary', bg: 'bg-primary/10' },
              { icon: Users, title: 'Add Team Members', sub: 'Invite your colleagues to collaborate', color: 'text-warning', bg: 'bg-warning/10' },
              { icon: Calendar, title: 'Integrate Google Calendar', sub: 'Sync your appointments seamlessly', color: 'text-info', bg: 'bg-info/10' },
              { icon: CreditCard, title: 'Connect Stripe Account', sub: 'Start accepting payments', color: 'text-danger', bg: 'bg-danger/10' },
              { icon: Box, title: 'Explore App Marketplace', sub: 'Find more tools and integrations', color: 'text-gray-600', bg: 'bg-gray-100' },
            ].map((card, idx) => (
              <button key={idx} className="flex items-center gap-5 bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all hover:border-gray-300 group text-left w-full">
                <div className={`h-14 w-14 rounded-full flex items-center justify-center shrink-0 ${card.bg} ${card.color}`}>
                  <card.icon size={28} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg text-gray-900 group-hover:text-primary transition-colors">{card.title}</h3>
                  <p className="text-sm text-gray-500 mt-1">{card.sub}</p>
                </div>
                <div className="h-8 w-8 rounded-full bg-gray-50 flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-colors">
                   <ChevronRight size={18} />
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Launchpad;
