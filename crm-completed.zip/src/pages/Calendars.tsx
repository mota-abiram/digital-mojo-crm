import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Plus, X } from 'lucide-react';
import { useStore } from '../store/useStore';
import {
    format,
    addDays,
    startOfWeek,
    endOfWeek,
    addWeeks,
    subWeeks,
    startOfMonth,
    endOfMonth,
    eachDayOfInterval,
    isSameDay,
    isSameMonth,
    addMonths,
    subMonths,
    parseISO,
    getHours,
    set
} from 'date-fns';

const Calendars: React.FC = () => {
    const { appointments, fetchAppointments, addAppointment } = useStore();
    const [currentDate, setCurrentDate] = useState(new Date());
    const [view, setView] = useState('Week');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [formData, setFormData] = useState({
        title: '',
        date: format(new Date(), 'yyyy-MM-dd'),
        time: '09:00',
        assignedTo: 'Me',
        notes: ''
    });

    useEffect(() => {
        fetchAppointments();
    }, [fetchAppointments]);

    // Calendar Logic
    const weekStart = startOfWeek(currentDate);
    const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
    const hours = Array.from({ length: 13 }, (_, i) => i + 8); // 8 AM to 8 PM

    // Mini Calendar Logic
    const miniMonthStart = startOfMonth(currentDate);
    const miniMonthEnd = endOfMonth(currentDate);
    const miniCalendarStart = startOfWeek(miniMonthStart);
    const miniCalendarEnd = endOfWeek(miniMonthEnd);
    const miniCalendarDays = eachDayOfInterval({ start: miniCalendarStart, end: miniCalendarEnd });

    const handlePrev = () => {
        if (view === 'Week') setCurrentDate(subWeeks(currentDate, 1));
        else setCurrentDate(subMonths(currentDate, 1));
    };

    const handleNext = () => {
        if (view === 'Week') setCurrentDate(addWeeks(currentDate, 1));
        else setCurrentDate(addMonths(currentDate, 1));
    };

    const handleCreate = async () => {
        await addAppointment({
            title: formData.title,
            date: formData.date,
            time: formData.time,
            assignedTo: formData.assignedTo,
            notes: formData.notes
        });
        setIsModalOpen(false);
        setFormData({ ...formData, title: '', notes: '' });
    };

    const getAppointmentsForDayAndTime = (day: Date, hour: number) => {
        return appointments.filter(apt => {
            try {
                const aptDate = parseISO(apt.date);
                const aptHour = parseInt(apt.time.split(':')[0]);
                return isSameDay(aptDate, day) && aptHour === hour;
            } catch (e) { return false; }
        });
    };

    return (
        <div className="p-8 h-full flex flex-col">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-gray-900">Calendars</h1>
                <div className="flex gap-2">
                    <div className="bg-gray-200 rounded-lg p-1 flex text-sm font-medium">
                        <button className="px-3 py-1.5 rounded-md text-gray-600 hover:text-gray-900">Calendars</button>
                        <button className="px-3 py-1.5 rounded-md bg-white shadow text-gray-900">Appointments</button>
                    </div>
                    <button
                        onClick={() => setIsModalOpen(true)}
                        className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2"
                    >
                        <Plus size={18} /> New Appointment
                    </button>
                </div>
            </div>

            <div className="flex gap-6 flex-1 min-h-0">
                {/* Mini Calendar & Filters */}
                <div className="w-72 flex-shrink-0 flex flex-col gap-6">
                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
                        <div className="flex justify-between items-center mb-4">
                            <span className="font-bold text-gray-800">{format(currentDate, 'MMMM yyyy')}</span>
                            <div className="flex gap-1 text-gray-500">
                                <ChevronLeft size={20} className="cursor-pointer hover:text-gray-800" onClick={() => setCurrentDate(subMonths(currentDate, 1))} />
                                <ChevronRight size={20} className="cursor-pointer hover:text-gray-800" onClick={() => setCurrentDate(addMonths(currentDate, 1))} />
                            </div>
                        </div>
                        <div className="grid grid-cols-7 text-center text-xs text-gray-500 mb-2">
                            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => <div key={d} className="py-1">{d}</div>)}
                        </div>
                        <div className="grid grid-cols-7 text-center text-sm">
                            {miniCalendarDays.map((day, i) => {
                                const isCurrentMonth = isSameMonth(day, currentDate);
                                const isSelected = isSameDay(day, currentDate);
                                return (
                                    <div key={i} className={`py-1.5 ${!isCurrentMonth ? 'text-gray-300' : 'text-gray-700'}`}>
                                        <button
                                            onClick={() => setCurrentDate(day)}
                                            className={`w-7 h-7 flex items-center justify-center rounded-full mx-auto ${isSelected ? 'bg-primary text-white' : 'hover:bg-gray-100'}`}
                                        >
                                            {format(day, 'd')}
                                        </button>
                                    </div>
                                )
                            })}
                        </div>
                    </div>

                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                        <h3 className="font-bold text-gray-900 mb-4 text-sm">Upcoming Appointments</h3>
                        <div className="space-y-4 max-h-60 overflow-y-auto">
                            {appointments.slice(0, 3).map((apt) => (
                                <div key={apt.id} className="border-b border-gray-100 pb-2 last:border-0">
                                    <p className="text-sm font-bold text-gray-800">{apt.title}</p>
                                    <p className="text-xs text-gray-500">{apt.date} at {apt.time}</p>
                                </div>
                            ))}
                            {appointments.length === 0 && <p className="text-sm text-gray-400">No upcoming appointments.</p>}
                        </div>
                    </div>
                </div>

                {/* Main View */}
                <div className="flex-1 bg-white rounded-xl border border-gray-200 shadow-sm flex flex-col min-w-0 overflow-hidden">
                    {/* Toolbar */}
                    <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                        <div className="flex items-center gap-4">
                            <div className="flex bg-gray-100 rounded-lg p-1">
                                <button onClick={handlePrev} className="p-1 hover:bg-white rounded shadow-sm"><ChevronLeft size={20} className="text-gray-600" /></button>
                                <button onClick={handleNext} className="p-1 hover:bg-white rounded shadow-sm"><ChevronRight size={20} className="text-gray-600" /></button>
                            </div>
                            <span className="text-lg font-bold text-gray-800">
                                {view === 'Week' ? `${format(weekStart, 'MMM d')} - ${format(addDays(weekStart, 6), 'MMM d, yyyy')}` : format(currentDate, 'MMMM yyyy')}
                            </span>
                        </div>
                        <div className="bg-gray-100 p-1 rounded-lg flex text-sm font-medium">
                            {['Month', 'Week', 'Day'].map(v => (
                                <button
                                    key={v}
                                    onClick={() => setView(v)}
                                    className={`px-3 py-1.5 rounded-md ${view === v ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}
                                >
                                    {v}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Week Header */}
                    <div className="grid grid-cols-8 border-b border-gray-200">
                        <div className="col-span-1 border-r border-gray-100"></div>
                        {weekDays.map((day, i) => (
                            <div key={i} className={`col-span-1 text-center py-3 border-r border-gray-100 ${isSameDay(day, new Date()) ? 'bg-primary/5' : ''}`}>
                                <div className={`text-xs font-semibold ${isSameDay(day, new Date()) ? 'text-primary' : 'text-gray-500'}`}>{format(day, 'EEE').toUpperCase()}</div>
                                <div className={`text-xl font-light mt-1 ${isSameDay(day, new Date()) ? 'text-primary font-bold' : 'text-gray-800'}`}>{format(day, 'd')}</div>
                            </div>
                        ))}
                    </div>

                    {/* Time Grid */}
                    <div className="flex-1 overflow-y-auto no-scrollbar relative">
                        <div className="grid grid-cols-8 relative">
                            {/* Time Column */}
                            <div className="col-span-1 border-r border-gray-200 bg-gray-50/50">
                                {hours.map(h => (
                                    <div key={h} className="h-20 border-b border-gray-100 text-xs text-gray-400 text-right pr-3 pt-2 relative">
                                        <span className="-top-3 relative">
                                            {h > 12 ? h - 12 : h} {h >= 12 ? 'PM' : 'AM'}
                                        </span>
                                    </div>
                                ))}
                            </div>

                            {/* Days Columns Background */}
                            {weekDays.map((day, i) => (
                                <div key={i} className="col-span-1 border-r border-gray-100 relative">
                                    {hours.map(h => (
                                        <div key={h} className="h-20 border-b border-gray-100 relative group">
                                            {/* Render Appointments */}
                                            {getAppointmentsForDayAndTime(day, h).map(apt => (
                                                <div key={apt.id} className="absolute inset-1 bg-primary text-white p-1 rounded text-xs overflow-hidden z-10 shadow-sm cursor-pointer hover:bg-primary/90">
                                                    <div className="font-bold">{apt.title}</div>
                                                    <div className="opacity-80">{apt.time}</div>
                                                </div>
                                            ))}
                                        </div>
                                    ))}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200">
                        <div className="flex justify-between items-center p-6 border-b border-gray-200 bg-gray-50">
                            <h3 className="text-xl font-bold text-gray-900">New Appointment</h3>
                            <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                                <X size={24} />
                            </button>
                        </div>
                        <div className="p-6 space-y-4">
                            <div>
                                <label className="block mb-2 text-sm font-medium text-gray-900">Title</label>
                                <input
                                    type="text"
                                    value={formData.title}
                                    onChange={e => setFormData({ ...formData, title: e.target.value })}
                                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block mb-2 text-sm font-medium text-gray-900">Date</label>
                                    <input
                                        type="date"
                                        value={formData.date}
                                        onChange={e => setFormData({ ...formData, date: e.target.value })}
                                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                                    />
                                </div>
                                <div>
                                    <label className="block mb-2 text-sm font-medium text-gray-900">Time</label>
                                    <input
                                        type="time"
                                        value={formData.time}
                                        onChange={e => setFormData({ ...formData, time: e.target.value })}
                                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block mb-2 text-sm font-medium text-gray-900">Notes</label>
                                <textarea
                                    value={formData.notes}
                                    onChange={e => setFormData({ ...formData, notes: e.target.value })}
                                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                                />
                            </div>
                        </div>
                        <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-200 bg-gray-50">
                            <button onClick={() => setIsModalOpen(false)} className="text-gray-700 bg-white border border-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-2.5 hover:bg-gray-50">Cancel</button>
                            <button onClick={handleCreate} className="text-white bg-success hover:bg-success/90 focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5">Create</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Calendars;
