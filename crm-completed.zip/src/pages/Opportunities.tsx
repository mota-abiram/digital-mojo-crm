import React, { useState, useEffect } from 'react';
import { Plus, MoreHorizontal, X } from 'lucide-react';
import { useStore } from '../store/useStore';
import { DndContext, DragEndEvent, useDraggable, useDroppable } from '@dnd-kit/core';
import { Opportunity } from '../types';

const STAGES = [
    { id: 'New', title: 'New', color: '#f0bc00' },
    { id: 'Contacted', title: 'Contacted', color: '#754c9b' },
    { id: 'Qualified', title: 'Qualified', color: '#06aed7' },
    { id: 'Proposal', title: 'Proposal', color: '#eb7311' },
    { id: 'Closed', title: 'Closed', color: '#1ea34f' },
];

const DraggableCard = ({ item, color }: { item: Opportunity, color: string }) => {
    const { attributes, listeners, setNodeRef, transform } = useDraggable({
        id: item.id,
    });

    const style = transform ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
    } : undefined;

    return (
        <div
            ref={setNodeRef}
            style={style}
            {...listeners}
            {...attributes}
            className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-all cursor-grab relative overflow-hidden group mb-3 z-10"
        >
            <div className="absolute left-0 top-0 bottom-0 w-1.5" style={{ backgroundColor: color }}></div>
            <div className="flex justify-between items-start mb-2 pl-2">
                <h4 className="font-bold text-gray-900">{item.name}</h4>
            </div>
            <p className="text-sm font-medium text-gray-500 pl-2 mb-4">${Number(item.value).toLocaleString()}</p>
            <div className="flex justify-between items-center pl-2">
                <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-xs font-bold text-gray-600">
                    {item.owner ? item.owner.charAt(0) : 'U'}
                </div>
                <span className="text-xs text-gray-400">Just now</span>
            </div>
        </div>
    );
};

const DroppableColumn = ({ stage, items }: { stage: typeof STAGES[0], items: Opportunity[] }) => {
    const { setNodeRef } = useDroppable({
        id: stage.id,
    });

    const totalValue = items.reduce((sum, item) => sum + Number(item.value), 0);

    return (
        <div ref={setNodeRef} className="w-80 flex flex-col bg-gray-100 rounded-xl shadow-inner max-h-full">
            <div className="p-4 flex justify-between items-center shrink-0">
                <div>
                    <h3 className="font-bold text-gray-800">{stage.title}</h3>
                    <p className="text-xs font-bold text-gray-500 mt-1">${totalValue.toLocaleString()}</p>
                </div>
                <button className="text-gray-400 hover:text-gray-600"><MoreHorizontal size={20} /></button>
            </div>

            <div className="p-4 pt-0 flex-1 overflow-y-auto custom-scrollbar min-h-[100px]">
                {items.map(item => (
                    <DraggableCard key={item.id} item={item} color={stage.color} />
                ))}
                <button className="w-full py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-400 text-sm font-medium hover:border-gray-400 hover:text-gray-500 transition-colors mt-2">
                    + Add Opportunity
                </button>
            </div>
        </div>
    );
};

const Opportunities: React.FC = () => {
    const { opportunities, fetchOpportunities, updateOpportunity, addOpportunity } = useStore();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [formData, setFormData] = useState({ name: '', value: '', stage: 'New' });

    useEffect(() => {
        fetchOpportunities();
    }, [fetchOpportunities]);

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;
        if (over && active.id !== over.id) {
            const stageId = over.id as string;
            updateOpportunity(active.id as string, { stage: stageId });
        }
    };

    const handleCreate = async () => {
        await addOpportunity({
            name: formData.name,
            value: Number(formData.value),
            stage: formData.stage,
            owner: 'Current User',
            status: 'Open',
            tags: []
        });
        setIsModalOpen(false);
        setFormData({ name: '', value: '', stage: 'New' });
    };

    return (
        <div className="p-8 h-full flex flex-col">
            <div className="flex justify-between items-center mb-8 shrink-0">
                <h1 className="text-3xl font-bold text-gray-900">Opportunities</h1>
                <div className="flex gap-3">
                    <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-bold text-gray-700 hover:bg-gray-50 shadow-sm">Pipelines</button>
                    <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-bold text-gray-700 hover:bg-gray-50 shadow-sm">Actions</button>
                    <button
                        onClick={() => setIsModalOpen(true)}
                        className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-bold hover:bg-primary/90 flex items-center gap-2 shadow-sm"
                    >
                        <Plus size={18} /> New
                    </button>
                </div>
            </div>

            <DndContext onDragEnd={handleDragEnd}>
                <div className="flex-1 overflow-x-auto overflow-y-hidden">
                    <div className="flex h-full gap-6 min-w-max pb-4">
                        {STAGES.map(stage => (
                            <DroppableColumn
                                key={stage.id}
                                stage={stage}
                                items={opportunities.filter(o => o.stage === stage.id)}
                            />
                        ))}
                    </div>
                </div>
            </DndContext>

            {/* Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200">
                        <div className="flex justify-between items-center p-6 border-b border-gray-200 bg-gray-50">
                            <h3 className="text-xl font-bold text-gray-900">New Opportunity</h3>
                            <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                                <X size={24} />
                            </button>
                        </div>
                        <div className="p-6 space-y-4">
                            <div>
                                <label className="block mb-2 text-sm font-medium text-gray-900">Name</label>
                                <input
                                    type="text"
                                    value={formData.name}
                                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                                />
                            </div>
                            <div>
                                <label className="block mb-2 text-sm font-medium text-gray-900">Value ($)</label>
                                <input
                                    type="number"
                                    value={formData.value}
                                    onChange={e => setFormData({ ...formData, value: e.target.value })}
                                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                                />
                            </div>
                            <div>
                                <label className="block mb-2 text-sm font-medium text-gray-900">Stage</label>
                                <select
                                    value={formData.stage}
                                    onChange={e => setFormData({ ...formData, stage: e.target.value })}
                                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                                >
                                    {STAGES.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}
                                </select>
                            </div>
                        </div>
                        <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-200 bg-gray-50">
                            <button onClick={() => setIsModalOpen(false)} className="text-gray-700 bg-white border border-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-2.5 hover:bg-gray-50">Cancel</button>
                            <button onClick={handleCreate} className="text-white bg-success hover:bg-success/90 focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5">Create</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Opportunities;
