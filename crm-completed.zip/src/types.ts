export interface User {
  id: string;
  name: string;
  avatar: string;
}

export interface Contact {
  id: string;
  name: string;
  email: string;
  phone: string;
  tags: string[];
  owner: string;
  type: 'Lead' | 'Customer' | 'Prospect' | 'High-Value';
  createdAt?: string;
}

export interface Opportunity {
  id: string;
  name: string;
  value: number;
  owner: string; // Changed from User to string to match requirement "Owner" field usually being a name or ID
  stage: string;
  status: 'Open' | 'Won' | 'Lost' | 'Abandoned';
  notes?: string;
  createdAt?: string;
  tags: string[];
}

export interface PipelineColumn {
  id: string;
  title: string;
  color: string;
  totalValue: number;
  items: Opportunity[];
}

export interface Message {
  id: string;
  sender: string;
  recipient: string;
  message: string;
  timestamp: string;
  // UI helper fields
  text?: string; // mapping message to text for UI compatibility if needed
  isMe?: boolean;
}

export interface Conversation {
  id: string;
  contactId: string;
  contactName: string;
  lastMessage: string;
  time: string;
  unread: boolean;
  messages: Message[];
}

export interface Appointment {
  id: string;
  title: string;
  time: string;
  date: string; // ISO date string
  assignedTo: string;
  notes: string;
  contactId?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  color: string;
  description: string;
  contact: string;
}
